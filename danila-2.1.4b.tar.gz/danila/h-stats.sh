#!/usr/bin/env bash

	CUSTOM_DIR=$(dirname "$BASH_SOURCE")

	source $CUSTOM_DIR/h-manifest.conf

	LOAD_LIMIT=5
	algo="darkcoin"

	khs=0
	stats=0
	gpu_stats=$(< $GPU_STATS_JSON)

	#readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan, .power, .load | join(" ")' $GPU_STATS_JSON 2>/dev/null)
	readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
	busids=(${gpu_stats[0]})
	brands=(${gpu_stats[1]})
	temps=(${gpu_stats[2]})
	fans=(${gpu_stats[3]})
	#power=(${gpu_stats[4]})
	#load=(${gpu_stats[5]})
	count=${#busids[@]}

	hash_arr=()
	busid_arr=()
	fan_arr=()
	temp_arr=()
	found=0
	uptime=0
	khs=0
	hashes=()
	cards=()
	miner_stats=()

	if [[ -f $CUSTOM_DIR/stats.json && `stat -c %Y $CUSTOM_DIR/stats.json` -gt $((`date +%s`-15)) ]]; then
		readarray -t miner_stats < <( jq -r '(.uptime|floor),(.shares|.[]),(.total|floor),([.rates|.[]|floor|tostring]|join(" ")),([.cards|.[]|floor|tostring]|join(" "))' $CUSTOM_DIR/stats.json )
		uptime=${miner_stats[0]}
		found=${miner_stats[1]}
		khs=${miner_stats[2]}
		hash_arr=( ${miner_stats[3]} )
		busid_arr=( ${miner_stats[4]} )
	else
		echo "No stats"
	fi

	idx=0
	for(( i=0; i < count; i++ )); do
		#[[ "${brands[i]}" == "cpu" ]] && continue
		[[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
		[[ $((16#${BASH_REMATCH[1]})) != ${busid_arr[idx]} ]] && continue
		temp_arr+=(${temps[i]})
		fan_arr+=(${fans[i]})
		((idx++))
	done

	hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
	bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`
	fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
	temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

	# uptime
	#if [[ $uptime -eq 0 ]]; then
	#	readarray -t pids < <( pgrep danila-miner )
	#	[[ ! -z ${pids[0]} && -e /proc/${pids[0]} ]] &&
	#		uptime=$(( `date +%s` - `stat -c%X /proc/${pids[0]}` ))
	#fi

	# found
	#found=$(grep -c "FOUND" $CUSTOM_LOG_BASENAME.log 2>/dev/null)

	# wrong
	#wrong=$(grep -c "WRONG" $CUSTOM_LOG_BASENAME.log 2>/dev/null)

	stats=$(jq -n --arg found $found --arg algo "$algo" --argjson bus_numbers "$bus_numbers" --argjson fan "$fan_json" \
		--argjson temp "$temp_json" --argjson hs "$hash_json" --arg uptime "$uptime" --arg ver "$CUSTOM_VERSION" \
		'{hs_units: "mhs", $hs, $algo, $ver, $uptime, $bus_numbers, $temp, $fan, ar:[$found|tonumber]}')

	#echo $khs
	#echo $stats
