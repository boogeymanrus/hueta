#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

#[[ ! $CUSTOM_URL =~ ^kf.* ]] && echo "${RED}Bad GIVER address${NOCOLOR}" && return 3
[[ ! $CUSTOM_TEMPLATE =~ ^EQ.* ]] && echo "${RED}Bad WALLET address${NOCOLOR}" && return 3

conf="WALLET=$CUSTOM_TEMPLATE"$'\n'

GIVERS=()
for pool_url in $CUSTOM_URL; do
	GIVERS+=("$pool_url")
done
conf+="GIVERS=( ${GIVERS[@]} )"$'\n'

[[ ! -z $CUSTOM_PASS ]] && conf+="BOOST=($CUSTOM_PASS)"$'\n'

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+="${CUSTOM_USER_CONFIG}"$'\n'

#[[ ! -z $WORKER_NAME ]] && conf=$(sed "s/%WORKER_NAME%/$WORKER_NAME/g" <<< "$conf") #|| echo "${RED}WORKER_NAME not set${NOCOLOR}"

echo "$conf" > $CUSTOM_CONFIG_FILENAME
