#!/usr/bin/env bash

	CUSTOM_DIR=$(dirname "$BASH_SOURCE")

	USE_AMD=1
	USE_NVIDIA=1

	source $CUSTOM_DIR/h-manifest.conf
	source $CUSTOM_CONFIG_FILENAME

	algo="darkcoin"
	khs=0
	stats=
	gpu_stats=$(< $GPU_STATS_JSON)

	readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
	busids=(${gpu_stats[0]})
	brands=(${gpu_stats[1]})
	temps=(${gpu_stats[2]})
	fans=(${gpu_stats[3]})

	count=${#busids[@]}

	total_hash=0
	hash_arr=()
	busid_arr=()
	fan_arr=()
	temp_arr=()
	gpu=0

	USE_ONLY=( ${USE_ONLY[@]} )
	now=$(( $(date +%s) - 30 ))
	for(( i=0; i < count; i++ )); do
		[[ "${brands[i]}" == "cpu" ||
			("${brands[i]}" == "amd" && $USE_AMD -eq 0) ||
			("${brands[i]}" == "nvidia" && $USE_NVIDIA -eq 0) ]] && continue
		if [[ ${#USE_ONLY} -gt 0 && ! " ${USE_ONLY[@]} " =~ " $gpu " ]]; then
			((gpu++))
			continue
		fi
		hash=0
		[[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
		busid_arr+=( $((16#${BASH_REMATCH[1]})) )
		temp_arr+=(${temps[i]})
		fan_arr+=(${fans[i]})
		#if [[ -f $CUSTOM_LOG_BASEDIR/gpu$gpu.log ]]; then
		#	log=$(tail -n 2 $CUSTOM_LOG_BASEDIR/gpu$gpu.log)
		#	[[ $log =~ instant\ speed:\ ([0-9]+) ]] && hash="${BASH_REMATCH[1]}"
		if [[ -f $CUSTOM_LOG_BASEDIR/stat$gpu.json ]]; then
			readarray -t stat < <(jq -r '(.speed|tonumber|floor),(.timestamp|tonumber|floor)' $CUSTOM_LOG_BASEDIR/stat$gpu.json)
			[[ ${stat[1]} != "null" && ${stat[1]} -ge $now && ${stat[0]} != "null" ]] && hash=${stat[0]}
		else
			echo "No stats for GPU $gpu"
		fi
		hash_arr+=($hash)
		total_hash=$(( total_hash + hash ))
		((gpu++))
	done

	khs=$(( total_hash*1000 ))
	hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
	bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`
	fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
	temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

	# emulate uptime
	start_time=`stat -c %Y $CUSTOM_CONFIG_FILENAME 2>/dev/null` &&
		uptime=$((`date +%s` - $start_time)) || uptime=

	# found
	found=$(grep "FOUND!" $CUSTOM_LOG_BASEDIR/gpu*.log 2>/dev/null | wc -l)

	stats=$(jq -n --arg found $found --arg algo "$algo"  --argjson bus_numbers "$bus_numbers" --argjson fan "$fan_json" \
		--argjson temp "$temp_json" --argjson hs "$hash_json" --arg uptime "$uptime" --arg ver "$CUSTOM_VERSION" \
		'{hs_units: "mhs", $hs, $algo, $ver, $uptime, $bus_numbers, $temp, $fan, ar:[$found]}')

	#echo $khs
	#echo $stats
