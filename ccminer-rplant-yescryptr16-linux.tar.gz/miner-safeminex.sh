#!/bin/sh
#
# Choose nearest stratum:
#       stratum-eu.rplant.xyz   /France/
#       stratum-asia.rplant.xyz /Singapore/
#       stratum-na.rplant.xyz   /Canada/
#
FOLDER=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
while [ 1 ]; do
"$FOLDER"/ccminer -a yescryptr16 -o stratum+tcp://stratum-eu.rplant.xyz:7053 -u WALLET_ADDRESS.WORKER_NAME
sleep 5
done